import React from 'react';
import { Camera, Leaf, Search, ChevronRight, GitBranch as BrandTelegram, Instagram, Brain, Database, Code, Zap, Server, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';

function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-gray-800">
        <nav className="container mx-auto px-4 py-6 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <Leaf className="w-8 h-8 text-green-500 floating-animation" />
            <span className="text-2xl font-bold gradient-text">HARVEST PULSE</span>
          </div>
          <div className="hidden md:flex space-x-8">
            <a href="#" className="text-gray-400 hover:text-green-500 transition-colors">Главная</a>
            <a href="#" className="text-gray-400 hover:text-green-500 transition-colors">О проекте</a>
            <a href="#" className="text-gray-400 hover:text-green-500 transition-colors">Технология</a>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div className="slide-in">
            <div className="inline-block px-4 py-2 bg-green-500/10 rounded-full mb-6">
              <span className="text-green-400 text-sm pulse-animation">Альфа версия 0.1</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-8 leading-tight">
              <span className="gradient-text">Умное распознавание</span>
              <br />болезней растений
            </h1>
            <p className="text-xl text-gray-400 mb-10">
              Используйте камеру вашего телефона для мгновенной диагностики здоровья растений. 
              Проект находится на начальной стадии разработки.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/scan" className="btn-primary">
                <span>Начать распознавание</span>
                <ChevronRight className="w-5 h-5" />
              </Link>
              <div className="flex gap-4">
                <a href="https://t.me/Actionsspeaklouder" 
                   target="_blank" 
                   rel="noopener noreferrer"
                   className="bg-gray-900 p-3 rounded-lg hover:bg-gray-800 transition-all duration-300 hover:scale-110">
                  <BrandTelegram className="w-6 h-6 text-green-500" />
                </a>
                <a href="https://www.instagram.com/harvest_pulse?igsh=MTNqYTM4ZXZxbHlldQ==" 
                   target="_blank" 
                   rel="noopener noreferrer"
                   className="bg-gray-900 p-3 rounded-lg hover:bg-gray-800 transition-all duration-300 hover:scale-110">
                  <Instagram className="w-6 h-6 text-green-500" />
                </a>
              </div>
            </div>
          </div>
          <div className="relative floating-animation">
            <div className="absolute inset-0 bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-2xl -z-10 blur-3xl"></div>
            <img
              src="https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
              alt="Здоровые растения"
              className="rounded-2xl border border-gray-800 shadow-2xl shadow-green-500/20 transition-all duration-500 hover:shadow-green-500/40 hover:scale-105"
            />
          </div>
        </div>
      </section>

      {/* Technology Stack */}
      <section className="py-20 bg-gradient-to-b from-gray-900/50 to-black">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">
            <span className="gradient-text">Технологический стек</span>
          </h2>
          <div className="flex flex-wrap justify-center gap-4 mb-16">
            <span className="tech-pill">Datasets</span>
            <span className="tech-pill">machine learning</span>
            <span className="tech-pill">computer vision</span>
            <span className="tech-pill">Github</span>
            <span className="tech-pill">Visual Studio code</span>
            <span className="tech-pill">Live Share</span>
            <span className="tech-pill">Ai Toolkit</span>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="feature-card">
              <div className="bg-green-500/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <Brain className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Искусственный интеллект</h3>
              <p className="text-gray-400">Использование передовых нейронных сетей для точного распознавания болезней растений</p>
            </div>
            <div className="feature-card">
              <div className="bg-green-500/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <Database className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Большая база данных</h3>
              <p className="text-gray-400">Постоянно растущая база данных различных заболеваний растений</p>
            </div>
            <div className="feature-card">
              <div className="bg-green-500/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <Camera className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Мгновенный анализ</h3>
              <p className="text-gray-400">Быстрая обработка фотографий и предоставление результатов</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">
            <span className="gradient-text">Преимущества системы</span>
          </h2>
          <div className="grid md:grid-cols-4 gap-8">
            <div className="feature-card">
              <div className="bg-green-500/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <Zap className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Быстрая работа</h3>
              <p className="text-gray-400">Мгновенное определение болезней с помощью камеры смартфона</p>
            </div>
            <div className="feature-card">
              <div className="bg-green-500/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <Search className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Точная диагностика</h3>
              <p className="text-gray-400">Высокая точность определения заболеваний растений</p>
            </div>
            <div className="feature-card">
              <div className="bg-green-500/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <Server className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Облачная обработка</h3>
              <p className="text-gray-400">Все вычисления производятся на серверах</p>
            </div>
            <div className="feature-card">
              <div className="bg-green-500/10 w-16 h-16 rounded-xl flex items-center justify-center mb-6">
                <Lock className="w-8 h-8 text-green-500" />
              </div>
              <h3 className="text-xl font-semibold mb-4">Безопасность</h3>
              <p className="text-gray-400">Надежная защита данных и конфиденциальность</p>
            </div>
          </div>
        </div>
      </section>

      {/* Development Status */}
      <section className="container mx-auto px-4 py-20">
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-8 md:p-12 hover:border-green-500/30 transition-all duration-500">
          <h2 className="text-3xl font-bold mb-6">
            <span className="gradient-text">Статус разработки</span>
          </h2>
          <p className="text-gray-400 mb-6">
            Проект HARVEST PULSE находится на начальной стадии разработки (альфа версия 0.1). 
            В настоящее время мы работаем над:
          </p>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h3 className="text-xl font-semibold mb-4">Текущие задачи</h3>
              <ul className="space-y-4 text-gray-400">
                <li className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full pulse-animation"></div>
                  <span>Улучшение точности распознавания болезней</span>
                </li>
                <li className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full pulse-animation"></div>
                  <span>Расширение базы данных заболеваний растений</span>
                </li>
                <li className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full pulse-animation"></div>
                  <span>Оптимизация алгоритмов машинного обучения</span>
                </li>
              </ul>
            </div>
            <div className="space-y-4">
              <h3 className="text-xl font-semibold mb-4">Планируемые функции</h3>
              <ul className="space-y-4 text-gray-400">
                <li className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  <span>Рекомендации по лечению растений</span>
                </li>
                <li className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  <span>История сканирований и отчеты</span>
                </li>
                <li className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  <span>Интеграция с умными теплицами</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default App;