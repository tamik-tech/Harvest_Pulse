import React, { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Leaf, Upload, ArrowLeft, Camera, AlertCircle } from 'lucide-react';

function Scan() {
  const [preview, setPreview] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    handleFile(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  };

  const handleAnalysis = () => {
    setIsAnalyzing(true);
    // Имитация процесса анализа
    setTimeout(() => {
      setIsAnalyzing(false);
      alert('Функция анализа будет доступна в следующей версии');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="border-b border-gray-800">
        <nav className="container mx-auto px-4 py-6 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <Leaf className="w-8 h-8 text-green-500 floating-animation" />
            <span className="text-2xl font-bold gradient-text">HARVEST PULSE</span>
          </div>
          <Link to="/" className="text-gray-400 hover:text-green-500 transition-colors flex items-center gap-2 hover:scale-105 transition-transform">
            <ArrowLeft className="w-5 h-5" />
            Назад
          </Link>
        </nav>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto slide-in">
          <h1 className="text-4xl font-bold mb-8">
            <span className="gradient-text">Загрузите фотографию</span>
          </h1>
          <p className="text-gray-400 mb-8">
            Загрузите фотографию растения для анализа. Убедитесь, что фотография четкая и хорошо освещена.
          </p>

          {/* Guidelines */}
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-6 mb-8">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-green-500" />
              Рекомендации по фотографии
            </h3>
            <ul className="space-y-2 text-gray-400">
              <li>• Фотографируйте при хорошем освещении</li>
              <li>• Держите камеру близко к растению (20-30 см)</li>
              <li>• Убедитесь, что симптомы заболевания хорошо видны</li>
              <li>• Избегайте размытых снимков</li>
            </ul>
          </div>

          {/* Upload Area */}
          <div
            className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-300
              ${isDragging ? 'border-green-500 bg-green-500/10 scale-105' : 'border-gray-700 hover:border-green-500/50'}
              ${preview ? 'border-solid' : ''}`}
            onDrop={handleDrop}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onClick={() => fileInputRef.current?.click()}
          >
            {preview ? (
              <div className="relative">
                <img src={preview} alt="Preview" className="rounded-xl max-h-[400px] mx-auto" />
                <button 
                  className="absolute top-4 right-4 bg-black/50 p-2 rounded-lg hover:bg-black/70 transition-colors"
                  onClick={(e) => {
                    e.stopPropagation();
                    setPreview(null);
                  }}
                >
                  Удалить
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-green-500/10 w-16 h-16 rounded-xl flex items-center justify-center mx-auto floating-animation">
                  <Upload className="w-8 h-8 text-green-500" />
                </div>
                <div>
                  <p className="text-lg mb-2">Перетащите фотографию сюда или нажмите для выбора</p>
                  <p className="text-gray-500">PNG, JPG до 10MB</p>
                </div>
              </div>
            )}
            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              accept="image/*"
              onChange={handleFileInput}
            />
          </div>

          {/* Camera Button */}
          <button 
            className="mt-6 w-full bg-gray-900 border border-gray-800 rounded-xl p-4 flex items-center justify-center gap-3 hover:border-green-500/30 transition-all hover:scale-105"
            onClick={() => {
              alert('Функция камеры будет доступна в следующей версии');
            }}
          >
            <Camera className="w-5 h-5 text-green-500" />
            <span>Открыть камеру</span>
          </button>

          {/* Analysis Button */}
          {preview && (
            <button 
              className={`mt-8 btn-primary w-full justify-center ${isAnalyzing ? 'animate-pulse' : ''}`}
              onClick={handleAnalysis}
              disabled={isAnalyzing}
            >
              {isAnalyzing ? 'Анализ...' : 'Начать анализ'}
            </button>
          )}
        </div>
      </main>
    </div>
  );
}

export default Scan;